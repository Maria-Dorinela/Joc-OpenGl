#include "Framework/DrawingWindow.h"
#include "Framework/Visual2D.h"
#include "Framework/Transform2D.h"
#include "Framework/Transform3D.h"
#include "Framework/Line2D.h"
#include "Framework/Rectangle2D.h"
#include "Framework/Circle2D.h"
#include "Framework/Polygon2D.h"
#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <ctime>
#include <vector>


#define PI 3.14159265358979323846
#define inf 1000000
using namespace std;
float l = 0;
Visual2D *v2d1, *v2d2;
Visual2D *v2d3, *v2d4, *v2d5;
Circle2D *cerc_nava, *cerc_arma, *impuscatura;
Polygon2D *poligon_nava,*poligon_1, *poligon_2, *poligon_3, *poligon_4, *poligon_5, *poligon_6, *poligon_7, *poligon_8, *poligon_9, *poligon_10;
Polygon2D *poligon_11, *poligon_12, *poligon_13, *poligon_14, *poligon_15, *poligon_16, *poligon_17, *poligon_18, *poligon_19;
Polygon2D *arma, *poligon_2_copy;
Polygon2D *naveta_scor;
Point2D *centru_p1, *centru_p2, *centru_p3, *centru_p4, *centru_p5, *centru_p6, *centru_p7, *centru_p8, *centru_p9, *centru_p10, *centru_p11;
Point2D *centru_p12, *centru_p13, *centru_p14, *centru_p15, *centru_p16, *centru_p17, *centru_p18, *centru_p19;
Text *scor, *scor1, *vieti_nava, *vieti_nava1, *game_over;
bool ok = false;
int nr_vieti_naveta = 10;
int scor_naveta = 0;
float n=1;
float x_cerc = 0, x_cerc_arma = 0;//x centrului armei si centrului proiectilului
float y_cerc = 0, y_cerc_arma = 0; //y centrului armei si centrului proiectilului
float rotire_nava = 0; 
float TX1, TY1;
float raza_rotire_arma = 0; //raza pe care se roteste arma fata de centrul navei
float raza_rotire_arma_2 =0;//raza pe care se roteste arma pana la baza triunghiului
float rotire_left = 0, rotire_right = 0;//variabile care retin cu cat s-a rotit nava la stanga sau la dreapta
float pierde_viata = 0;
float pierde_viata1 = 0;
float panta = 0;
//vector de puncte

//functie care returneaza un numar aleator intre 2 numere de tip float date ca parametru
float RandomFloat(float a, float b) {
    float random = ((float) rand()) / (float) RAND_MAX;
    float diff = b - a;
    float r = random * diff;
	float result  = a + r;
	result = floor(result * 1000) / 1000;
	return result;
	
}

//functie care returneaza un numar random cuprins intre doua numere de tip int date ca parametri
int RandomFloatInt(int a, int b){
	int random = ((int) rand()) / (int) RAND_MAX;
    int diff = b - a;
    int r = random * diff;
	int result  = a + r;
	return result;
}

//functie care transforma un int in string
string int_to_string(int number){
  if (number == 0)
        return "0";
    string temp="";
    string returnvalue="";
    while (number>0)
    {
        temp+=number%10+48;
        number/=10;
    }
    for (int i=0;i<temp.length();i++)
        returnvalue+=temp[temp.length()-i-1];
    return returnvalue;
}

//functia care permite adaugarea de obiecte
void DrawingWindow::init()
{
	v2d1 = new Visual2D(-6,-0.57,6,0.57,0,0,DrawingWindow::width,DrawingWindow::height/8); 
	v2d1->tipTran(true);
	addVisual2D(v2d1);
	
	v2d2 = new Visual2D(-6,-4,6,4,0,DrawingWindow::height/8,DrawingWindow::width,DrawingWindow::height); 
	v2d2->tipTran(true);
	addVisual2D(v2d2);
	
	//retinere scor si vieti

	//scor naveta
	scor = new Text("SCORE: ",Point2D(-1,0),Color(0, 0, 0.803922),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(scor, v2d1);
	string s = int_to_string(scor_naveta);
	scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(scor1, v2d1);

	vieti_nava = new Text("X ", Point2D(4.2,-0.1), Color(1,0,0),BITMAP_HELVETICA_18);
	addText_to_Visual2D(vieti_nava, v2d1);

	string v_naveta = int_to_string(nr_vieti_naveta);
	vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
	addText_to_Visual2D(vieti_nava1, v2d1);

	naveta_scor = new Polygon2D(Color(1,0,0), false);
	naveta_scor->addPoint(Point2D(5.3,-0.1));
	naveta_scor->addPoint(Point2D(5.1,-0.3));
	naveta_scor->addPoint(Point2D(4.9,0));
	naveta_scor->addPoint(Point2D(5.1,0.3));
	naveta_scor->addPoint(Point2D(5.3,0.1));
	naveta_scor->addPoint(Point2D(5.2,0.2));
	naveta_scor->addPoint(Point2D(5.1,0));
	naveta_scor->addPoint(Point2D(5.2,-0.2));
	naveta_scor->addPoint(Point2D(5.3,-0.1));
	addObject2D_to_Visual2D(naveta_scor,v2d1);
	
	Line2D *linie = new Line2D(Point2D(6, -3),Point2D(7, -3), Color(0,1,0));
	addObject2D_to_Visual2D(linie, v2d1);
	
	
	//desenare jucatori
	y_cerc = -3;
	x_cerc = 5.4;
	//desenare cerc pentru naveta spatiala
	cerc_nava = new Circle2D(Point2D(x_cerc,y_cerc),0.6,Color(1,0,0),false);
	addObject2D_to_Visual2D(cerc_nava, v2d2);

	//desenare arma
	arma = new Polygon2D(Color(0,0,0),true);
	arma->addPoint(Point2D(4.7,-3.3));
	arma->addPoint(Point2D(4.7,-2.7));
	arma->addPoint(Point2D(3.8,-3));
	arma->addPoint(Point2D(4.7,-3.3));
	addObject2D_to_Visual2D(arma,v2d2);

	//cerc_copy = new Circle2D();
	x_cerc_arma = arma->transf_points[2]->x;
	y_cerc_arma = arma->transf_points[2]->y;
	impuscatura = new Circle2D(Point2D(x_cerc_arma,y_cerc_arma), 0.1, Color(0,0,0), true);
	
	//desenare poligon pentru naveta
	poligon_nava = new Polygon2D(Color(1,0,0),false);
	poligon_nava->addPoint(Point2D(5.8, -3.3));
	poligon_nava->addPoint(Point2D(5.6, -3.4));
	poligon_nava->addPoint(Point2D(5.4,-3.5));
	poligon_nava->addPoint(Point2D(5.1,-3));
	poligon_nava->addPoint(Point2D(5.4,-2.5));
	poligon_nava->addPoint(Point2D(5.6,-2.6));
	poligon_nava->addPoint(Point2D(5.8,-2.7));
	poligon_nava->addPoint(Point2D(5.6,-2.6));
	poligon_nava->addPoint(Point2D(5.4,-3));
	poligon_nava->addPoint(Point2D(5.6,-3.4));
	addObject2D_to_Visual2D(poligon_nava, v2d2);
	Transform2D::translateMatrix(-5.4, 3);
	Transform2D::rotateMatrix(110);
	Transform2D::translateMatrix(5.4, -3);
	Transform2D::applyTransform_o(poligon_nava);

	//desenare inamici
	//2 patrate in dreapta
	poligon_1 = new Polygon2D(Color(0.6, 0.196078, 0.8), false);
	poligon_1->addPoint(Point2D(2,2));
	poligon_1->addPoint(Point2D(2,2.5));
	poligon_1->addPoint(Point2D(2.5,2.5));
	poligon_1->addPoint(Point2D(2.5,2.2));
	poligon_1->addPoint(Point2D(2.3,2.2));
	poligon_1->addPoint(Point2D(2.3,2));
	poligon_1->addPoint(Point2D(2.5,2));
	poligon_1->addPoint(Point2D(2.5,2.2));
	poligon_1->addPoint(Point2D(2.8,2.2));
	poligon_1->addPoint(Point2D(2.8,1.7));
	poligon_1->addPoint(Point2D(2.3,1.7));
	poligon_1->addPoint(Point2D(2.3,2));
	poligon_1->addPoint(Point2D(2,2));
	addObject2D_to_Visual2D(poligon_1, v2d2);
	centru_p1 = new Point2D((2+2.8)/2, (2.5+1.7)/2);
	

	//patrat cu romb verde inchis
	poligon_2 = new Polygon2D(Color(0, 0.392157, 0), false);
	poligon_2->addPoint(Point2D(0,0));
	poligon_2->addPoint(Point2D(0,0.5));
	poligon_2->addPoint(Point2D(0.5,0.5));
	poligon_2->addPoint(Point2D(0.5,0));
	poligon_2->addPoint(Point2D(0,0));
	poligon_2->addPoint(Point2D(0,0.25));
	poligon_2->addPoint(Point2D(0.25,0.5));
	poligon_2->addPoint(Point2D(0.5,0.25));
	poligon_2->addPoint(Point2D(0.25,0));
	poligon_2->addPoint(Point2D(0,0.25));
	addObject2D_to_Visual2D(poligon_2, v2d2);
	centru_p2 = new Point2D(0.25, 0.25);

	//patrat cu romb mov deschis
	poligon_2_copy = new Polygon2D(Color(0.482353, 0.407843, 0.933333), false);
	poligon_2_copy->addPoint(Point2D(2,0.2));
	poligon_2_copy->addPoint(Point2D(2,0.7));
	poligon_2_copy->addPoint(Point2D(2.5,0.7));
	poligon_2_copy->addPoint(Point2D(2.5,0.2));
	poligon_2_copy->addPoint(Point2D(2,0.2));
	poligon_2_copy->addPoint(Point2D(2,0.45));
	poligon_2_copy->addPoint(Point2D(2.25,0.7));
	poligon_2_copy->addPoint(Point2D(2.5,0.45));
	poligon_2_copy->addPoint(Point2D(2.25,0.2));
	poligon_2_copy->addPoint(Point2D(2,0.45));
	addObject2D_to_Visual2D(poligon_2_copy, v2d2);

	//avion albastru
	poligon_3 = new Polygon2D(Color(0,0,1), false);
	poligon_3->addPoint(Point2D(-1.8,0.8));
	poligon_3->addPoint(Point2D(-0.9,0.5));
	poligon_3->addPoint(Point2D(-1.8,0.2));
	poligon_3->addPoint(Point2D(-1.5,0.5));
	poligon_3->addPoint(Point2D(-1.8,0.8));
	addObject2D_to_Visual2D(poligon_3, v2d2);
	centru_p3 = new Point2D(-1.35,0.5);

	//romb cu patrat
	poligon_4 = new Polygon2D(Color(1,1,0), false);
	poligon_4->addPoint(Point2D(3,2.5));
	poligon_4->addPoint(Point2D(3.5,3));
	poligon_4->addPoint(Point2D(4,2.5));
	poligon_4->addPoint(Point2D(3.5,2));
	poligon_4->addPoint(Point2D(3,2.5));
	poligon_4->addPoint(Point2D(3.3,2.8));
	poligon_4->addPoint(Point2D(3.7,2.8));
	poligon_4->addPoint(Point2D(3.7,2.2));
	poligon_4->addPoint(Point2D(3.3,2.2));
	poligon_4->addPoint(Point2D(3.3,2.8));
	addObject2D_to_Visual2D(poligon_4, v2d2);
	centru_p4 = new Point2D(3.5,2.5);

	//multe patrate verzi
	poligon_5 = new Polygon2D(Color(0,1,0), true);
	poligon_5->addPoint(Point2D(-1,-1));
	poligon_5->addPoint(Point2D(-0.25,-1));
	poligon_5->addPoint(Point2D(-0.25,-1.25));
	poligon_5->addPoint(Point2D(-0.75,-1.25));
	poligon_5->addPoint(Point2D(-0.75,-1.5));
	poligon_5->addPoint(Point2D(-1,-1.5));
	poligon_5->addPoint(Point2D(-1,-1));
	addObject2D_to_Visual2D(poligon_5, v2d2);
	centru_p5 = new Point2D(-0.625, -1.25);

	//avion verde catre nava
	poligon_6 = new Polygon2D(Color(0,1,0), false);
	poligon_6->addPoint(Point2D(4,-0.2));
	poligon_6->addPoint(Point2D(3.2,-0.5));
	poligon_6->addPoint(Point2D(4,-0.8));
	poligon_6->addPoint(Point2D(3.8,-0.5));
	poligon_6->addPoint(Point2D(4,-0.2));
	addObject2D_to_Visual2D(poligon_6, v2d2);
	centru_p6 = new Point2D(3.6,-0.5);

	//steluta sus
	poligon_7 = new Polygon2D(Color(0,1,0), false);
	poligon_7->addPoint(Point2D(0,2));
	poligon_7->addPoint(Point2D(0,2.1));
	poligon_7->addPoint(Point2D(0.3,2.3));
	poligon_7->addPoint(Point2D(0,2));
	poligon_7->addPoint(Point2D(0.1,2));
	poligon_7->addPoint(Point2D(0.3,1.7));
	poligon_7->addPoint(Point2D(0,2));
	poligon_7->addPoint(Point2D(0,1.9));
	poligon_7->addPoint(Point2D(-0.3,1.7));
	poligon_7->addPoint(Point2D(0,2));
	poligon_7->addPoint(Point2D(-0.1,2));
	poligon_7->addPoint(Point2D(-0.3,2.3));
	poligon_7->addPoint(Point2D(0,2));
	addObject2D_to_Visual2D(poligon_7, v2d2);
	centru_p7 = new Point2D(0,2);

	//steluta stanga
	poligon_8 = new Polygon2D(Color(1,0,1), false);
	poligon_8->addPoint(Point2D(-4,0));
	poligon_8->addPoint(Point2D(-4,0.1));
	poligon_8->addPoint(Point2D(-3.7,0.3));
	poligon_8->addPoint(Point2D(-4,0));
	poligon_8->addPoint(Point2D(-3.9,0));
	poligon_8->addPoint(Point2D(-3.7,-0.3));
	poligon_8->addPoint(Point2D(-4,0));
	poligon_8->addPoint(Point2D(-4,-0.1));
	poligon_8->addPoint(Point2D(-4.3,-0.3));
	poligon_8->addPoint(Point2D(-4,0));
	poligon_8->addPoint(Point2D(-4.1,0));
	poligon_8->addPoint(Point2D(-4.3,0.3));
	poligon_8->addPoint(Point2D(-4,0));
	addObject2D_to_Visual2D(poligon_8, v2d2);
	centru_p8 = new Point2D(-4,0);

	//2 cuburi blue
	poligon_9 = new Polygon2D(Color(0,1,1), false);
	poligon_9->addPoint(Point2D(-3,2));
	poligon_9->addPoint(Point2D(-3,2.25));
	poligon_9->addPoint(Point2D(-2.75,2.25));
	poligon_9->addPoint(Point2D(-2.75,2));
	poligon_9->addPoint(Point2D(-3,2));
	poligon_9->addPoint(Point2D(-2.85,2));
	poligon_9->addPoint(Point2D(-2.85,2.15));
	poligon_9->addPoint(Point2D(-2.65,2.15));
	poligon_9->addPoint(Point2D(-2.65,1.85));
	poligon_9->addPoint(Point2D(-2.85,1.85));
	poligon_9->addPoint(Point2D(-2.85,2));
	addObject2D_to_Visual2D(poligon_9, v2d2);
	centru_p9 = new Point2D(2.825, 2.05);

	//trifoi
	poligon_10 = new Polygon2D(Color(1, 0.270588, 0), false);
	poligon_10->addPoint(Point2D(0,-1));
	poligon_10->addPoint(Point2D(-0.2,-1.15));
	poligon_10->addPoint(Point2D(-0.2,-0.85));
	poligon_10->addPoint(Point2D(0,-1));
	poligon_10->addPoint(Point2D(-0.15,-0.8));
	poligon_10->addPoint(Point2D(0.15,-0.8));
	poligon_10->addPoint(Point2D(0,-1));
	poligon_10->addPoint(Point2D(0.2,-0.85));
	poligon_10->addPoint(Point2D(0.2,-1.15));
	poligon_10->addPoint(Point2D(0,-1));
	poligon_10->addPoint(Point2D(0.15,-1.2));
	poligon_10->addPoint(Point2D(-0.15,-1.2));
	poligon_10->addPoint(Point2D(0,-1));
	addObject2D_to_Visual2D(poligon_10, v2d2);
	centru_p10 = new Point2D(0,-1);

	//triunghiuri in sir

	//triunghi de jos (primul)
	poligon_11 = new Polygon2D(Color(1,0,0), true);
	poligon_11->addPoint(Point2D(-3,-3));
	poligon_11->addPoint(Point2D(-2.60,-3));
	poligon_11->addPoint(Point2D(-2.80,-2.75));
	poligon_11->addPoint(Point2D(-3,-3));
	
	addObject2D_to_Visual2D(poligon_11, v2d2);
	centru_p11 = new Point2D(-2.8,-2.875);

	//triunghiul 2
	poligon_12 = new Polygon2D(Color(1,0,0), true);
	poligon_12->addPoint(Point2D(-3,-2.75));
	poligon_12->addPoint(Point2D(-2.60,-2.75));
	poligon_12->addPoint(Point2D(-2.80,-2.50));
	poligon_12->addPoint(Point2D(-3,-2.75));
	addObject2D_to_Visual2D(poligon_12, v2d2);
	centru_p12 = new Point2D(-2.8, -2.625);

	//triunghiul 3
	poligon_13 = new Polygon2D(Color(1,0,0), true);
	poligon_13->addPoint(Point2D(-3,-2.50));
	poligon_13->addPoint(Point2D(-2.60,-2.50));
	poligon_13->addPoint(Point2D(-2.80,-2.25));
	poligon_13->addPoint(Point2D(-3,-2.50));
	addObject2D_to_Visual2D(poligon_13, v2d2);
	centru_p13 = new Point2D(-2.8, -2.375);


	//triunghiul 4
	poligon_14 = new Polygon2D(Color(1,0,0), true);
	poligon_14->addPoint(Point2D(-3,-2.25));
	poligon_14->addPoint(Point2D(-2.60,-2.25));
	poligon_14->addPoint(Point2D(-2.80,-2));
	poligon_14->addPoint(Point2D(-3,-2.25));
	addObject2D_to_Visual2D(poligon_14, v2d2);
	centru_p14 = new Point2D(-2.8, -125);

	//patrate in sir

	//patrat 1
	poligon_15 = new Polygon2D(Color(0,1,0), true);
	poligon_15->addPoint(Point2D(3.75,1));
	poligon_15->addPoint(Point2D(4,1));
	poligon_15->addPoint(Point2D(4,1.25));
	poligon_15->addPoint(Point2D(3.75,1.25));
	poligon_15->addPoint(Point2D(3.75,1));
	addObject2D_to_Visual2D(poligon_15, v2d2);
	centru_p15 = new Point2D(3.875,1.125);

	//patrat 2
	poligon_16 = new Polygon2D(Color(1,0,1), true);
	poligon_16->addPoint(Point2D(4,1));
	poligon_16->addPoint(Point2D(4.25,1));
	poligon_16->addPoint(Point2D(4.25,1.25));
	poligon_16->addPoint(Point2D(4,1.25));
	poligon_16->addPoint(Point2D(4,1));
	addObject2D_to_Visual2D(poligon_16, v2d2);
	centru_p16 = new Point2D(4.125, 1.125);

	//patrat 3
	poligon_17 = new Polygon2D(Color(0,0,1), true);
	poligon_17->addPoint(Point2D(3.75,1));
	poligon_17->addPoint(Point2D(3.5,1));
	poligon_17->addPoint(Point2D(3.5,1.25));
	poligon_17->addPoint(Point2D(3.75,1.25));
	poligon_17->addPoint(Point2D(3.75,1));
	addObject2D_to_Visual2D(poligon_17, v2d2);
	centru_p17 = new Point2D(3.625, 1.125);

	//patrat 4
	poligon_18 = new Polygon2D(Color(1,0,0), true);
	poligon_18->addPoint(Point2D(4,0.75));
	poligon_18->addPoint(Point2D(3.75,0.75));
	poligon_18->addPoint(Point2D(3.75,1));
	poligon_18->addPoint(Point2D(4,1));
	poligon_18->addPoint(Point2D(4,0.75));
	addObject2D_to_Visual2D(poligon_18, v2d2);
	centru_p18 = new Point2D(3.875, 0.875);


	//patrat
	poligon_19 = new Polygon2D(Color(1,0,0), true);
	poligon_19->addPoint(Point2D(4,1.25));
	poligon_19->addPoint(Point2D(4,1.5));
	poligon_19->addPoint(Point2D(3.75,1.5));
	poligon_19->addPoint(Point2D(3.75,1.25));
	poligon_19->addPoint(Point2D(4,1.25));
	addObject2D_to_Visual2D(poligon_19, v2d2);
	centru_p19 = new Point2D(3.875, 1.375);

}




//functia care permite animatia
void DrawingWindow::onIdle()
{
	static float pas = 0;
	static float scale = 1;
	static float iter = 0;
	static float iter_1 = 0;
	static float ty1 = 0, ty2 = 0, ty3 = 0, ty4 = 0, ty5 = 0, ty6 = 0, ty7 = 0, ty8 = 0, ty9 = 0, ty10 = 0, ty11 = 0, ty12 = 0, ty13 = 0, ty14 = 0, ty15 = 0, ty16 = 0, ty17 = 0, ty18 = 0, ty19 = 0;
	static float tx1 = 0, tx2 = 0, tx3 = 0, tx4 = 0, tx5 = 0, tx6 = 0, tx7 = 0, tx8 = 0, tx9 = 0, tx10 = 0, tx11 = 0, tx12 = 0, tx13 = 0, tx14 = 0, tx15 = 0, tx16 = 0, tx17 = 0, tx18 = 0, tx19 = 0;
	static float TX1 = 0, TX2 = 0, TX3 = 0, TX4 = 0, TX5 = 0, TX6 = 0, TX7 = 0, TX8 = 0, TX9 = 0, TX10 = 0, TX11 = 0, TX12 = 0, TX13 = 0, TX14 = 0, TX15 = 0, TX16 = 0, TX17 = 0, TX18 = 0, TX19 = 0;
	static float TY1 = 0, TY2 = 0, TY3 = 0, TY4 = 0, TY5 = 0, TY6 = 0, TY7 = 0, TY8 = 0, TY9 = 0, TY10 = 0, TY11 = 0, TY12 = 0, TY13 = 0, TY14 = 0, TY15 = 0, TY16 = 0, TY17 = 0, TY18 = 0, TY19 = 0;
	float distanta = 0;
	float xxxx = 0;
	float yyyy= 0;
	float l = 0;

	int r1 = RandomFloatInt(20,50);
	int r2 = RandomFloatInt(50,70);
	int r3 = RandomFloatInt(70,90);
	int r4 = RandomFloatInt(90,120);
	int r5 = RandomFloatInt(120,150);
	int r6 = RandomFloatInt(150,170);
	int r7 = RandomFloatInt(170,200);
	int r8 = RandomFloatInt(200,230);
	int r9 = RandomFloatInt(230,260);
	int r10 = RandomFloatInt(260,300);

	float t1, t11, t2, t21, t3, t31, t4, t41, t5, t51, t6, t61, t7, t71, t8, t81, t9, t91, t10, t101, t;
	int i = 0;
	float x_trage = 0;
	float y_trage = 0;
	float suma_raze = 0;
	iter++;
	
	//deplasare inamici si detectarea coliziunilor intre ei si nava
	if (iter <= r1){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.05);
		ty1 += t1;
		//tx1 += 0;
		centru_p1->x += 0;
		centru_p1->y +=t1;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_1, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
	

		t2 = RandomFloat(0,0.03);
		ty2 += t2;
		//tx2 += 0;
		centru_p2->x += 0;
		centru_p2->y +=t2;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_2, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t3 = RandomFloat(0,0.03);
		ty3 += t3;
		//tx3 += 0;
		centru_p3->x += 0;
		centru_p3->y +=t3;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_3, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t4 = RandomFloat(0,0.03);
		ty4 -= t4;
		//tx4 += 0;
		centru_p4->x += 0;
		centru_p4->y -= t4;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_4, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t5 = RandomFloat(0,0.03);
		ty5 -= t5;
		//tx5 += 0;
		centru_p5->x += 0;
		centru_p5->y -= t5;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_5, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t6 = RandomFloat(0,0.03);
		ty6 -= t6;
		//tx6 += 0;
		centru_p6->x += 0;
		centru_p6->y -= t6;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_6, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t7 = RandomFloat(0,0.03);
		ty7 -= t7;
		//tx7 += 0;
		centru_p7->x += 0;
		centru_p7->y -= t7;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_7, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t8 = RandomFloat(0,0.03);
		ty8 -= t8;
		//tx8 += 0;
		centru_p8->x += 0;
		centru_p8->y -= t8;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_8, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t9 = RandomFloat(0,0.03);
		ty9 -= t9;
		//tx9 += 0;
		centru_p9->x += 0;
		centru_p9->y -= t9;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_9, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t10 = RandomFloat(0,0.03);
		ty10 -= t10;
		//tx10 += 0;
		centru_p10->x += 0;
		centru_p10->y -=t10;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_10, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		   
		}
		t = RandomFloat(0,0.03);
		ty11 += t;
		//tx11 += 0;
		centru_p11->x += 0;
		centru_p11->y += t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_11, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		ty12 += t;
		//tx12 += 0;
		centru_p12->x += 0;
		centru_p12->y += t;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_12, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		ty13 += t;
		//tx13 += 0;
		centru_p13->x += 0;
		centru_p13->y += t;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_13, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty14 += t;
		//tx14 += 0;
		centru_p14->x += 0;
		centru_p14->y += t;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_14, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.04);
		tx15 -= t;
		//ty15 += 0;
		centru_p15->x -= t;
		centru_p15->y += 0;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_15, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 -= t;
		//ty16 += 0;
		centru_p16->x -= t;
		centru_p16->y += 0;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_16, v2d2);
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 -= t;
		//ty17 += 0;
		centru_p17->x -= t;
		centru_p17->y += 0;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx18 -= t;
		//ty18 += 0;
		centru_p18->x -= t;
		centru_p18->y += 0;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx19 -= t;
		//ty19 += 0;
		centru_p19->x -= t;
		centru_p19->y += 0;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
	}

	else if (iter <= r2){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.05);
		ty1 -= t1;
		//tx1 += 0;
		centru_p1->x += 0;
		centru_p1->y -=t1;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t2 = RandomFloat(0,0.03);
		ty2 -= t2;
		//tx2 += 0;
		centru_p2->x += 0;
		centru_p2->y -=t2;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.03);
		ty3 -= t3;
		//tx3 += 0;
		centru_p3->x += 0;
		centru_p3->y -=t3;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.03);
		ty4 += t4;
		//tx4 += 0;
		centru_p4->x += 0;
		centru_p4->y +=t4;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t5 = RandomFloat(0,0.03);
		ty5 += t5;
		//tx5 += 0;
		centru_p5->x += 0;
		centru_p5->y += t5;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.03);
		ty6 += t6;
		//tx6 += 0;
		centru_p6->x += 0;
		centru_p6->y += t6;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.03);
		ty7 += t7;
		//tx7 += 0;
		centru_p7->x += 0;
		centru_p7->y += t7;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.03);
		ty8 += t8;
		//tx8 += 0;
		centru_p8->x += 0;
		centru_p8->y += t8;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.03);
		ty9 += t9;
		//tx9 += 0;
		centru_p9->x += 0;
		centru_p9->y += t9;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10= RandomFloat(0,0.03);
		ty10 += t10;
		//tx10 += 0;
		
		centru_p10->x += 0;
		centru_p10->y +=t10;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.03);
		ty11 -= t;
		//tx11 += 0;
		centru_p11->x += 0;
		centru_p11->y -= t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty12 -= t;
		//tx12 += 0;
		centru_p12->x += 0;
		centru_p12->y -= t;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty13 -= t;
		//tx13 += 0;
		centru_p13->x += 0;
		centru_p13->y -= t;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty14 -= t;
		//tx14 += 0;
		centru_p14->x += 0;
		centru_p14->y -= t;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.04);
		tx15 += t;
		//ty15 += 0;
		centru_p15->x += t;
		centru_p15->y += 0;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 += t;
		//ty16 += 0;
		centru_p16->x += t;
		centru_p16->y += 0;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 += t;
		//ty17 += 0;
		centru_p17->x += t;
		centru_p17->y += 0;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx18 += t;
		//ty18 += 0;
		centru_p18->x += t;
		centru_p18->y += 0;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx19 += t;
		//ty19 += 0;
		centru_p19->x += t;
		centru_p19->y += 0;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
	}
	else if(iter <= r3){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.03);
		tx1 += t1;
		//ty1 += 0;
		centru_p1->x += t1;
		centru_p1->y += 0;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx1 -= 2*t1;
			ty1 += 0;
			centru_p1->x -= 2*t1;
			centru_p1->y += 0;
		}
		
		t2 = RandomFloat(0,0.03);
		tx2 += t2;
		//ty2 += 0;
		centru_p2->x += t2;
		centru_p2->y += 0;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx2 -= 2*t2;
			ty2 += 0;
			centru_p2->x -= 2*t2;
			centru_p2->y += 0;
		}

		t3 = RandomFloat(0,0.03);
		tx3 += t3;
		//ty3 += 0;
		centru_p3->x += t3;
		centru_p3->y += 0;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx3 -= 2*t3;
			ty3 += 0;
			centru_p3->x -= 2*t3;
			centru_p3->y += 0;
		}

		t4 = RandomFloat(0,0.03);
		tx4 += t4;
		//ty4 += 0;
		centru_p4->x += t4;
		centru_p4->y -= 0;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx4 -= 2*t4;
			ty4 += 0;
			centru_p4->x -= 2*t4;
			centru_p4->y -= 0;
		}

		t5 = RandomFloat(0,0.03);
		tx5 -= t5;
		//ty5 += 0;
		centru_p5->x -= t5;
		centru_p5->y -= 0;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx5 += 2*t5;
			ty5 += 0;
			centru_p5->x += 2*t5;
			centru_p5->y -= 0;
		}

		t6 = RandomFloat(0,0.03);
		tx6 -= t6;
		//ty6 += 0;
		centru_p6->x -= t6;
		centru_p6->y -= 0;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx6 += 2*t6;
			//ty6 += 0;
			centru_p6->x += 2*t6;
			centru_p6->y -= 0;
		}

		t7 = RandomFloat(0,0.03);
		tx7 -= t7;
		//ty7 += 0;
		centru_p7->x -= t7;
		centru_p7->y -= 0;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx7 += 2*t7;
			//ty7 += 0;
			centru_p7->x += 2*t7;
			centru_p7->y -= 0;
		}

		t8 = RandomFloat(0,0.03);
		tx8 += t8;
		//ty8 += 0;
		centru_p8->x += t8;
		centru_p8->y -= 0;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx8 -= 2*t8;
			//ty8 += 0;
			centru_p8->x -= 2*t8;
			centru_p8->y -= 0;
		}

		t9 = RandomFloat(0,0.03);
		tx9 += t9;
		//ty9 += 0;
		centru_p9->x += t9;
		centru_p9->y -= 0;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx9 -= 2*t9;
			//ty9 += 0;
			centru_p9->x -= 2*t9;
			centru_p9->y -= 0;
		}

		t10 = RandomFloat(0,0.03);
		tx10 += t10;
		//ty10 += 0;
		centru_p10->x += t10;
		centru_p10->y += 0;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx10 -= 2*t10;
			//ty10 += 0;
			centru_p10->x -= 2*t10;
			centru_p10->y += 0;
		}
		t = RandomFloat(0,0.03);
		ty11 += t;
		//tx11 += 0;
		centru_p11->x += 0;
		centru_p11->y += t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty11 -= 2*t;
			//tx11 += 0;
			centru_p11->x += 0;
			centru_p11->y -= 2*t;	
		}

		ty12 += t;
		//tx12 += 0;
		centru_p12->x += 0;
		centru_p12->y += t;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty12 -= 2*t;
			//tx12 += 0;
			centru_p12->x += 0;
			centru_p12->y -= 2*t;
		}

		ty13 += t;
		//tx13 += 0;
		centru_p13->x += 0;
		centru_p13->y += t;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty13 -= 2*t;
			//tx13 += 0;
			centru_p13->x += 0;
			centru_p13->y -= 2*t;	
		}

		ty14 += t;
		//tx14 += 0;
		centru_p14->x += 0;
		centru_p14->y += t;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty14 -= 2*t;
			//tx14 += 0;
			centru_p14->x += 0;
			centru_p14->y -= 2*t;
		}

		t = RandomFloat(0,0.02);
		ty15 += t;
		centru_p15->x -= 0;
		centru_p15->y += t;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty15 -= 2*t;
			centru_p15->x -= 0;
			centru_p15->y -= 2*t;
		}

		ty16 -= t;
		centru_p16->x -= 0;
		centru_p16->y -= t;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty16 += 2*t;
			centru_p16->x -= 0;
			centru_p16->y += 2*t;
		}

		ty17 -= t;
		centru_p17->x -= 0;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty17 += 2*t;
			centru_p17->x -= 0;
			centru_p17->y += 2*t;
		}

		ty18 += t;
		centru_p18->x -= 0;
		centru_p18->y += t;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty18 -= 2*t;
			centru_p18->x -= 0;
			centru_p18->y -= 2*t;
		}

		ty19 -= t;
		centru_p19->x -= 0;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty19 += 2*t;
			centru_p19->x -= 0;
			centru_p19->y += 2*t;
		}

	}
	else if(iter <= r4){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.03);
		tx1 -= t1;
		//ty1 += 0;
		centru_p1->x -= t1;
		centru_p1->y += 0;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx1 += 2*t1;
			//ty1 += 0;
			centru_p1->x += 2*t1;
			centru_p1->y += 0;
		}
		
		t2 = RandomFloat(0,0.03);
		tx2 -= t2;
		//ty2 += 0;
		centru_p2->x -= t2;
		centru_p2->y += 0;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx2 += 2*t2;
			//ty2 += 0;
			centru_p2->x += 2*t2;
			centru_p2->y += 0;
		}

		t3 = RandomFloat(0,0.05);
		tx3 -= t3;
		//ty3 += 0;
		centru_p3->x -= t3;
		centru_p3->y += 0;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx3 += 2*t3;
			//ty3 += 0;
			centru_p3->x += 2*t3;
			centru_p3->y += 0;
		}

		t4 = RandomFloat(0,0.03);
		tx4 -= t4;
		//ty4 += 0;
		centru_p4->x -= t4;
		centru_p4->y -= 0;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx4 += 2*t4;
			//ty4 += 0;
			centru_p4->x += 2*t4;
			centru_p4->y -= 0;
		}

		t5 = RandomFloat(0,0.05);
		tx5 += t5;
		//ty5 += 0;
		centru_p5->x += t5;
		centru_p5->y -= 0;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx5 -= 2*t5;
			//ty5 += 0;
			centru_p5->x -= 2*t5;
			centru_p5->y -= 0;
		}

		t6 = RandomFloat(0,0.03);
		tx6 += t6;
		//ty6 += 0;
		centru_p6->x += t6;
		centru_p6->y -= 0;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx6 -= 2*t6;
			//ty6 += 0;
			centru_p6->x -= 2*t6;
			centru_p6->y -= 0;
		}

		t7 = RandomFloat(0,0.03);
		tx7 += t7;
		//ty7 += 0;
		centru_p7->x += t7;
		centru_p7->y -= 0;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx7 -= 2*t7;
			//ty7 += 0;
			centru_p7->x -= 2*t7;
			centru_p7->y -= 0;
		}

		t8 = RandomFloat(0,0.03);
		tx8 -= t8;
		ty8 += 0;
		centru_p8->x -= t8;
		centru_p8->y -= 0;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx8 += 2*t8;
			//ty8 += 0;
			centru_p8->x += 2*t8;
			centru_p8->y -= 0;
		}

		t9 = RandomFloat(0,0.03);
		tx9 -= t9;
		//ty9 += 0;
		centru_p9->x -= t9;
		centru_p9->y -= 0;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx9 += 2*t9;
			//ty9 += 0;
			centru_p9->x += 2*t9;
			centru_p9->y -= 0;
		}

		t10 = RandomFloat(0,0.03);
		tx10 -= t10;
		//ty10 += 0;
		centru_p10->x -= t10;
		centru_p10->y += 0;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			tx10 += 2*t10;
			//ty10 += 0;
			centru_p10->x += 2*t10;
			centru_p10->y += 0;
		}
		t = RandomFloat(0,0.03);
		ty11 -= t;
		//tx11 += 0;
		centru_p11->x += 0;
		centru_p11->y -= t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty11 += 2*t;
			//tx11 += 0;
			centru_p11->x += 0;
			centru_p11->y += 2*t;
		}

		ty12 -= t;
		//tx12 += 0;
		centru_p12->x += 0;
		centru_p12->y -= t;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty12 += 2*t;
			//tx12 = 0;
			centru_p12->x += 0;
			centru_p12->y += 2*t;
		}

		ty13 -= t;
		//tx13 += 0;
		centru_p13->x += 0;
		centru_p13->y -= t;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty13 += 2*t;
			//tx13 += 0;
			centru_p13->x += 0;
			centru_p13->y += 2*t;
		}

		ty14 -= t;
		//tx14 += 0;
		centru_p14->x += 0;
		centru_p14->y -= t;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty14 += 2*t;
			//tx14 += 0;
			centru_p14->x += 0;
			centru_p14->y += 2*t;
		}

		t = RandomFloat(0,0.03);
		ty15 -= t;
		centru_p15->x -= 0;
		centru_p15->y -= t;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty15 += 2*t;
			centru_p15->x -= 0;
			centru_p15->y += 2*t;
		}

		ty16 -= t;
		centru_p16->x -= 0;
		centru_p16->y -= t;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty16 += 2*t;
			centru_p16->x -= 0;
			centru_p16->y += 2*t;	
		}

		ty17 -= t;
		centru_p17->x -= 0;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty17 += 2*t;
			centru_p17->x -= 0;
			centru_p17->y += 2*t;	
		}

		ty18 -= t;
		centru_p18->x -= 0;
		centru_p18->y -= t;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty18 += 2*t;
			centru_p18->x -= 0;
			centru_p18->y += 2*t;
		}

		ty19 -= t;
		centru_p19->x -= 0;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			ty19 += 2*t;
			centru_p19->x -= 0;
			centru_p19->y += 2*t;
		}
		
	}
	else if(iter <= r5){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.05);
		t11 = RandomFloat(0,0.05);
		tx1 -= t1;
		ty1 -= t11;
		centru_p1->x -= t1;
		centru_p1->y -= t11;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_1, v2d2);
			tx1 += t1;
			ty1 += t11;
			centru_p1->x += t1;
			centru_p1->y += t11;	
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		

		t2 = RandomFloat(0,0.03);
		t21 = RandomFloat(0,0.03);
		tx2 += t2;
		ty2 += t21;
		centru_p2->x += t2;
		centru_p2->y += t21;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_2, v2d2);
			tx2 -= t2;
			ty2 -= t21;
			centru_p2->x -= t2;
			centru_p2->y -= t21;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.03);
		t31 = RandomFloat(0,0.03);
		tx3 += t3;
		ty3 += t31;
		centru_p3->x += t3;
		centru_p3->y += t31;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_3, v2d2);
			tx3 -= t3;
			ty3 -= t31;
			centru_p3->x -= t3;
			centru_p3->y -= t31;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.03);
		t41 = RandomFloat(0,0.03);
		tx4 += t4;
		ty4 += t41;
		centru_p4->x += t4;
		centru_p4->y += t41;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_4, v2d2);
			tx4 -= t4;
			ty4 -= t41;
			centru_p4->x -= t4;
			centru_p4->y -= t41;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t5 = RandomFloat(0,0.03);
		t51 = RandomFloat(0,0.03);
		tx5 += t5;
		ty5 += t51;
		centru_p5->x += t5;
		centru_p5->y += t51;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_5, v2d2);
			tx5 -= t5;
			ty5 -= t51;
			centru_p5->x -= t5;
			centru_p5->y -= t51;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.03);
		t61 = RandomFloat(0,0.03);
		tx6 -= t6;
		ty6 -= t61;
		centru_p6->x -= t6;
		centru_p6->y -= t61;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_6, v2d2);
			tx6 += t6;
			ty6 += t61;
			centru_p6->x += t6;
			centru_p6->y += t61;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.03);
		t71 = RandomFloat(0,0.03);
		tx7 += t7;
		ty7 += t71;
		centru_p7->x += t7;
		centru_p7->y += t71;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_7, v2d2);
			tx7 -= t7;
			ty7 -= t71;
			centru_p7->x -= t7;
			centru_p7->y -= t71;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.03);
		t81 = RandomFloat(0,0.03);
		tx8 += t8;
		ty8 += t81;
		centru_p8->x += t8;
		centru_p8->y += t81;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_8, v2d2);
			tx8 -= t8;
			ty8 -= t81;
			centru_p8->x -= t8;
			centru_p8->y -= t81;	
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.03);
		t91 = RandomFloat(0,0.03);
		tx9 += t9;
		ty9 += t91;
		centru_p9->x += t9;
		centru_p9->y += t91;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_9, v2d2);
			tx9 -= t9;
			ty9 -= t91;
			centru_p9->x -= t9;
			centru_p9->y -= t91;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10 = RandomFloat(0,0.03);
		t101 = RandomFloat(0,0.03);
		tx10 += t10;
		ty10 += t101;
		centru_p10->x += t10;
		centru_p10->y += t101;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_10, v2d2);
			tx10 -= t10;
			ty10 -= t101;
			centru_p10->x -= t10;
			centru_p10->y -= t101;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.05);
		tx11 += t;
		//ty11 += 0;
		centru_p11->x += t;
		centru_p11->y += 0;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_11, v2d2);
			tx11 -= t;
			//ty11 += 0;
			centru_p11->x -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx12 += t;
		//ty12 += 0;
		centru_p12->x += t;
		centru_p12->y += 0;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_12, v2d2);
			tx12 -= t;
			//ty12 += 0;
			centru_p12->x -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx13 += t;
		ty13 += 0;
		centru_p13->x += t;
		centru_p13->y += 0;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_13, v2d2);
			tx13 -= t;
			//ty13 += 0;
			centru_p13->x -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx14 += t;
		//ty14 += 0;
		centru_p14->x += t;
		centru_p14->y += 0;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_14, v2d2);
			tx14 -= t;
			ty14 += 0;
			centru_p14->x -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.02);
		tx15 += t;
		//ty15 += 0;
		centru_p15->x += t;
		centru_p15->y -= 0;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_15, v2d2);
			tx15 -= t;
			ty15 += 0;
			centru_p15->x -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 -= t;
		ty16 += 0;
		centru_p16->x -= t;
		centru_p16->y += 0;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_16, v2d2);
			tx16 += t;
			ty16 += 0;
			centru_p16->x += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 -= t;
		ty17 += 0;
		centru_p17->x -= t;
		centru_p17->y += 0;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_17, v2d2);
			tx17 += t;
			ty17 += 0;
			centru_p17->x += t;
			centru_p17->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		tx18 -= t;
		ty18 += 0;
		centru_p18->x -= t;
		centru_p18->y += 0;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_18, v2d2);
			tx18 += t;
			ty18 += 0;
			centru_p18->x += t;
			centru_p18->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty19 -= t;
		tx19 += 0;
		centru_p19->x -= 0;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_19, v2d2);
			ty19 += t;
			tx19 += 0;
			centru_p19->x -= 0;
			centru_p19->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

	}
	else if(iter <= r6){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.03);
		t11 = RandomFloat(0,0.03);
		tx1 += t1;
		ty1 += t11;
		centru_p1->x += t1;
		centru_p1->y += t11;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_1, v2d2);
			tx1 -= t1;
			ty1 -= t11;
			centru_p1->x -= t1;
			centru_p1->y -= t11;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		

		t2 = RandomFloat(0,0.03);
		t21 = RandomFloat(0,0.03);
		tx2 -= t2;
		ty2 -= t21;
		centru_p2->x -= t2;
		centru_p2->y -= t21;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_2, v2d2);
			tx2 += t2;
			ty2 += t21;
			centru_p2->x += t2;
			centru_p2->y += t21;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.03);
		t31 = RandomFloat(0,0.03);
		tx3 -= t3;
		ty3 -= t31;
		centru_p3->x -= t3;
		centru_p3->y -= t31;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_3, v2d2);
			tx3 += t3;
			ty3 += t31;
			centru_p3->x += t3;
			centru_p3->y += t31;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.03);
		t41 = RandomFloat(0,0.03);
		tx4 -= t4;
		ty4 -= t41;
		centru_p4->x -= t4;
		centru_p4->y -= t41;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_4, v2d2);
			tx4 += t4;
			ty4 += t41;
			centru_p4->x += t4;
			centru_p4->y += t41;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t5 = RandomFloat(0,0.03);
		t51 = RandomFloat(0,0.03);
		tx5 -= t5;
		ty5 -= t51;
		centru_p5->x -= t5;
		centru_p5->y -= t51;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_5, v2d2);
			tx5 += t5;
			ty5 += t51;
			centru_p5->x += t5;
			centru_p5->y += t51;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.05);
		t61 = RandomFloat(0,0.05);
		tx6 += t6;
		ty6 += t61;
		centru_p6->x += t6;
		centru_p6->y += t61;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_6, v2d2);
			tx6 -= t6;
			ty6 -= t61;
			centru_p6->x -= t6;
			centru_p6->y -= t61;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.03);
		t71 = RandomFloat(0,0.03);
		tx7 -= t7;
		ty7 -= t71;
		centru_p7->x -= t7;
		centru_p7->y -= t71;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_7, v2d2);
			tx7 += t7;
			ty7 += t71;
			centru_p7->x += t7;
			centru_p7->y += t71;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.03);
		t81 = RandomFloat(0,0.03);
		tx8 -= t8;
		ty8 -= t81;
		centru_p8->x -= t8;
		centru_p8->y -= t81;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_8, v2d2);
			tx8 += t8;
			ty8 += t81;
			centru_p8->x += t8;
			centru_p8->y += t81;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.03);
		t91 = RandomFloat(0,0.03);
		tx9 -= t9;
		ty9 -= t91;
		centru_p9->x -= t9;
		centru_p9->y -= t91;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_9, v2d2);
			tx9 += t9;
			ty9 += t91;
			centru_p9->x += t9;
			centru_p9->y += t91;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10 = RandomFloat(0,0.05);
		t101 = RandomFloat(0,0.05);
		tx10 -= t10;
		ty10 -= t101;
		centru_p10->x -= t10;
		centru_p10->y -= t101;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_10, v2d2);
			tx10 += t10;
			ty10 += t101;
			centru_p10->x += t10;
			centru_p10->y += t101;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			
		}
		t = RandomFloat(0,0.05);
		tx11 -= t;
		ty11 += 0;
		centru_p11->x -= t;
		centru_p11->y += 0;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_11, v2d2);
			tx11 += t;
			ty11 += 0;
			centru_p11->x += t;
			centru_p11->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx12 -= t;
		ty12 += 0;
		centru_p12->x -= t;
		centru_p12->y += 0;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_12, v2d2);
			tx12 += t;
			ty12 += 0;
			centru_p12->x += t;
			centru_p12->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}


		tx13 -= t;
		ty13 += 0;
		centru_p13->x += -t;
		centru_p13->y += 0;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_13, v2d2);
			tx13 += t;
			ty13 += 0;
			centru_p13->x += t;
			centru_p13->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx14 -= t;
		ty14 += 0;
		centru_p14->x -= t;
		centru_p14->y += 0;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_14, v2d2);
			tx14 += t;
			ty14 += 0;
			centru_p14->x += t;
			centru_p14->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.02);
		tx15 -= t;
		ty15 += 0;
		centru_p15->x -= t;
		centru_p15->y -= 0;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_15, v2d2);
			tx15 += t;
			//ty15 += 0;
			centru_p15->x += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 += t;
		ty16 -= t;
		centru_p16->x += t;
		centru_p16->y -= t;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_16, v2d2);
			tx16 -= t;
			ty16 += t;
			centru_p16->x -= t;
			centru_p16->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 += t;
		ty17 -= t;
		centru_p17->x += t;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_17, v2d2);
			tx17 -= t;
			ty17 += t;
			centru_p17->x -= t;
			centru_p17->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx18 += t;
		ty18 += 0;
		centru_p18->x += t;
		centru_p18->y += 0;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_18, v2d2);
			tx18 -= t;
			//ty18 = 0;
			centru_p18->x -= t;
			centru_p18->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty19 += t;
		tx19 += 0;
		centru_p19->x -= 0;
		centru_p19->y += t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_19, v2d2);
			ty19 -= t;
			//tx19 = 0;
			centru_p19->x -= 0;
			centru_p19->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
	}
	else if(iter <= r7){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.03);
		t11 = RandomFloat(0,0.03);
		tx1 -= t1;
		ty1 += t11;
		centru_p1->x -= t1;
		centru_p1->y += t11;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_1, v2d2);
			tx1 += t1;
			ty1 -= t11;
			centru_p1->x += t1;
			centru_p1->y -= t11;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t2 = RandomFloat(0,0.03);
		t21 = RandomFloat(0,0.03);
		tx2 -= t2;
		ty2 -= t21;
		centru_p2->x -= t2;
		centru_p2->y -= t21;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_2, v2d2);
			tx2 += t2;
			ty2 += t21;
			centru_p2->x += t2;
			centru_p2->y += t21;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.05);
		t31 = RandomFloat(0,0.05);
		tx3 -= t3;
		ty3 += t31;
		centru_p3->x -= t3;
		centru_p3->y += t31;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_3, v2d2);
			tx3 += t3;
			ty3 -= t31;
			centru_p3->x += t3;
			centru_p3->y -= t31;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.03);
		t41 = RandomFloat(0,0.03);
		tx4 -= t4;
		ty4 += t41;
		centru_p4->x -= t4;
		centru_p4->y += t41;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_4, v2d2);
			tx4 += t4;
			ty4 -= t41;
			centru_p4->x += t4;
			centru_p4->y -= t41;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t5 = RandomFloat(0,0.03);
		t51 = RandomFloat(0,0.03);
		tx5 -= t5;
		ty5 += t51;
		centru_p5->x -= t5;
		centru_p5->y += t51;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_5, v2d2);
			tx5 += t5;
			ty5 -= t51;
			centru_p5->x += t5;
			centru_p5->y -= t51;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.03);
		t61 = RandomFloat(0,0.03);
		tx6 -= t6;
		ty6 += t61;
		centru_p6->x -= t6;
		centru_p6->y += t61;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_6, v2d2);
			tx6 += t6;
			ty6 -= t61;
			centru_p6->x += t6;
			centru_p6->y -= t61;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.03);
		t71 = RandomFloat(0,0.03);
		tx7 -= t7;
		ty7 += t71;
		centru_p7->x -= t7;
		centru_p7->y += t71;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_7, v2d2);
			tx7 += t7;
			ty7 -= t71;
			centru_p7->x += t7;
			centru_p7->y -= t71;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.03);
		t81 = RandomFloat(0,0.03);
		tx8 -= t8;
		ty8 += t81;
		centru_p8->x -= t8;
		centru_p8->y += t81;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_8, v2d2);
			tx8 += t8;
			ty8 -= t81;
			centru_p8->x += t8;
			centru_p8->y -= t81;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.03);
		t91 = RandomFloat(0,0.03);
		tx9 -= t9;
		ty9 += t91;
		centru_p9->x -= t9;
		centru_p9->y += t91;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_9, v2d2);
			tx9 += t9;
			ty9 -= t91;
			centru_p9->x += t9;
			centru_p9->y -= t91;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10 = RandomFloat(0,0.03);
		t101 = RandomFloat(0,0.03);
		tx10 -= t10;
		ty10 += t101;
		centru_p10->x -= t10;
		centru_p10->y += t101;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_10, v2d2);
			tx10 += t10;
			ty10 -= t101;
			centru_p10->x += t10;
			centru_p10->y -= t101;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		t = RandomFloat(0,0.08);
		
		ty14 += t;
		tx14 = 0;
		centru_p14->x += 0;
		centru_p14->y += t;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_14, v2d2);
			ty14 -= t;
			tx14 += 0;
			centru_p14->x += 0;
			centru_p14->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx13 += t;
		ty13 += t;
		centru_p13->x += t;
		centru_p13->y += t;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_13, v2d2);
			tx13 -= t;
			ty13 -= t;
			centru_p13->x -= t;
			centru_p13->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx12 += t;
		ty12 = 0;
		centru_p12->x += t;
		centru_p12->y += 0;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_12, v2d2);
			tx12 -= t;
			ty12 += 0;
			centru_p12->x -= t;
			centru_p12->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx11 += t;
		ty11 += t;
		centru_p11->x += t;
		centru_p11->y += t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_11, v2d2);
			tx11 -= t;
			ty11 -= t;
			centru_p11->x -= t;
			centru_p11->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t= RandomFloat(0,0.01);
		tx15 += t;
		ty15 += t;
		centru_p15->x += t;
		centru_p15->y += t;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_15, v2d2);
			tx15 -= t;
			ty15 -= t;
			centru_p15->x -= t;
			centru_p15->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 -= t;
		ty16 += 0;
		centru_p16->x -= t;
		centru_p16->y += 0;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_16, v2d2);
			tx16 += t;
			ty16 += 0;
			centru_p16->x += t;
			centru_p16->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 += 0;
		ty17 -= t;
		centru_p17->x -= 0;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_17, v2d2);
			tx17 += 0;
			ty17 += t;
			centru_p17->x -= 0;
			centru_p17->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		tx18 -= t;
		ty18 -= t;
		centru_p18->x -= t;
		centru_p18->y -= t;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_18, v2d2);
			tx18 += t;
			ty18 += t;
			centru_p18->x += t;
			centru_p18->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx19 += t;
		ty19 -= t;
		centru_p19->x += t;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_19, v2d2);
			tx19 -= t;
			ty19 += t;
			centru_p19->x -= t;
			centru_p19->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}


	}
	else if(iter <= r8){
		pierde_viata = 0;
		t1 = RandomFloat(0,0.03);
		t11 = RandomFloat(0,0.03);
		tx1 += t1;
		ty1 -= t11;
		centru_p1->x += t1;
		centru_p1->y -= t11;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_1, v2d2);
			tx1 -= t1;
			ty1 += t11;
			centru_p1->x -= t1;
			centru_p1->y += t11;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t2 = RandomFloat(0,0.03);
		t21 = RandomFloat(0,0.03);
		tx2 += t2;
		ty2 += t21;
		centru_p2->x += t2;
		centru_p2->y += t21;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_2, v2d2);
			tx2 -= t2;
			ty2 -= t21;
			centru_p2->x -= t2;
			centru_p2->y -= t21;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.03);
		t31 = RandomFloat(0,0.03);
		tx3 += t3;
		ty3 -= t31;
		centru_p3->x += t3;
		centru_p3->y -= t31;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_3, v2d2);
			tx3 -= t3;
			ty3 += t31;
			centru_p3->x -= t3;
			centru_p3->y += t31;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.03);
		t41 = RandomFloat(0,0.03);
		tx4 += t4;
		ty4 -= t41;
		centru_p4->x += t4;
		centru_p4->y -= t41;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_4, v2d2);
			tx4 -= t4;
			ty4 += t41;
			centru_p4->x -= t4;
			centru_p4->y += t41;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t5 = RandomFloat(0,0.03);
		t51 = RandomFloat(0,0.03);
		tx5 += t5;
		ty5 -= t51;
		centru_p5->x += t5;
		centru_p5->y -= t51;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_5, v2d2);
			tx5 -= t5;
			ty5 += t51;
			centru_p5->x -= t5;
			centru_p5->y += t51;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.03);
		t61 = RandomFloat(0,0.03);
		tx6 += t6;
		ty6 -= t61;
		centru_p6->x += t6;
		centru_p6->y -= t61;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_6, v2d2);
			tx6 -= t6;
			ty6 += t61;
			centru_p6->x -= t6;
			centru_p6->y += t61;	
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.04);
		t71 = RandomFloat(0,0.04);
		tx7 += t7;
		ty7 -= t71;
		centru_p7->x += t7;
		centru_p7->y -= t71;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_7, v2d2);
			tx7 -= t7;
			ty7 += t71;
			centru_p7->x -= t7;
			centru_p7->y += t71;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.03);
		t81 = RandomFloat(0,0.03);
		tx8 += t8;
		ty8 -= t81;
		centru_p8->x += t8;
		centru_p8->y -= t81;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_8, v2d2);
			tx8 -= t8;
			ty8 += t81;
			centru_p8->x -= t8;
			centru_p8->y += t81;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.04);
		t91 = RandomFloat(0,0.04);
		tx9 += t9;
		ty9 -= t91;
		centru_p9->x += t9;
		centru_p9->y -= t91;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_9, v2d2);
			tx9 -= t9;
			ty9 += t91;
			centru_p9->x -= t9;
			centru_p9->y += t91;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10 = RandomFloat(0,0.03);
		t101 = RandomFloat(0,0.03);
		tx10 += t10;
		ty10 -= t101;
		centru_p10->x += t10;
		centru_p10->y -=t101;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_10, v2d2);
			tx10 -= t10;
			ty10 += t101;
			centru_p10->x -= t10;
			centru_p10->y += t101;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		t = RandomFloat(0,0.05);

		ty14 -= t;
		tx14 += 0;
		centru_p14->x += 0;
		centru_p14->y -= t;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_14, v2d2);
			ty14 += t;
			tx14 += 0;
			centru_p14->x += 0;
			centru_p14->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx13 -= t;
		ty13 -= t;
		centru_p13->x -= t;
		centru_p13->y -= t;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_13, v2d2);
			tx13 += t;
			ty13 += t;
			centru_p13->x += t;
			centru_p13->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx12 -= t;
		ty12 += 0;
		centru_p12->x -= t;
		centru_p12->y += 0;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_12, v2d2);
			tx12 += t;
			ty12 -= 0;
			centru_p12->x += t;
			centru_p12->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx11 -= t;
		ty11 -= t;	
		centru_p11->x -= t;
		centru_p11->y -= t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_11, v2d2);
			tx11 += t;
			ty11 += t;	
			centru_p11->x += t;
			centru_p11->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t= RandomFloat(0,0.01);
		tx15 -= t;
		ty15 -= t;
		centru_p15->x -= t;
		centru_p15->y -= t;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_15, v2d2);
			tx15 += t;
			ty15 += t;
			centru_p15->x += t;
			centru_p15->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 += t;
		ty16 += 0;
		centru_p16->x += t;
		centru_p16->y += 0;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_16, v2d2);
			tx16 -= t;
			ty16 += 0;
			centru_p16->x -= t;
			centru_p16->y += 0;	
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 += 0;
		ty17 -= t;
		centru_p17->x -= 0;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_17, v2d2);
			tx17 += 0;
			ty17 += t;
			centru_p17->x += 0;
			centru_p17->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		tx18 += t;
		ty18 -= t;
		centru_p18->x += t;
		centru_p18->y -= t;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_18, v2d2);
			tx18 -= t;
			ty18 += t;
			centru_p18->x -= t;
			centru_p18->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx19 -= t;
		ty19 -= t;
		centru_p19->x -= t;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_19, v2d2);
			tx19 += t;
			ty19 += t;
			centru_p19->x += t;
			centru_p19->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

	}
	else if(iter <= r9){
		pierde_viata = 0;
		t1 = RandomFloatInt(0,0.02);
		tx1 += t1;
		ty1 += 0;
		centru_p1->x += t1;
		centru_p1->y += 0;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_1, v2d2);
			tx1 -= t1;
			ty1 += 0;
			centru_p1->x -= t1;
			centru_p1->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t2 = RandomFloatInt(0,0.02);
		ty2 += t2;
		tx2 += 0;
		centru_p2->x += 0;
		centru_p2->y += t2;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_2, v2d2);
			ty2 -= t2;
			tx2 += 0;
			centru_p2->x += 0;
			centru_p2->y -= t2;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.04);
		t31 = RandomFloat(0,0.04);
		tx3 -= t3;
		ty3 -= t31;
		centru_p3->x -= t3;
		centru_p3->y -= t31;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			//removeObject2D_from_Visual2D(poligon_3, v2d2);
			tx3 += t3;
			ty3 += t31;
			centru_p3->x += t3;
			centru_p3->y += t31;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.02);
		t41 = RandomFloat(0,0.02);
		tx4 += t4;
		ty4 += t41;
		centru_p4->x += t4;
		centru_p4->y += t41;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			
			tx4 -= t4;
			ty4 -= t41;
			centru_p4->x -= t4;
			centru_p4->y -= t41;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);

		}

		t5 = RandomFloat(0,0.02);
		t51 = RandomFloat(0,0.02);
		tx5 += t5;
		ty5 -= t51;
		centru_p5->x += t5;
		centru_p5->y -= t51;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			
			tx5 -= t5;
			ty5 += t51;
			centru_p5->x -= t5;
			centru_p5->y += t51;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.02);
		t61 = RandomFloat(0,0.02);
		tx6 -= t6;
		ty6 += t61;
		centru_p6->x -= t6;
		centru_p6->y += t61;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			
			tx6 += t6;
			ty6 -= t61;
			centru_p6->x += t6;
			centru_p6->y -= t61;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.02);
		t71 = RandomFloat(0,0.02);
		tx7 += t7;
		ty7 += t71;
		centru_p7->x += t7;
		centru_p7->y += t71;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			
			tx7 -= t7;
			ty7 -= t71;
			centru_p7->x -= t7;
			centru_p7->y -= t71;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.02);
		t81 = RandomFloat(0,0.02);
		tx8 += t8;
		ty8 += t81;
		centru_p8->x += t8;
		centru_p8->y += t81;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			
			tx8 -= t8;
			ty8 -= t81;
			centru_p8->x -= t8;
			centru_p8->y -= t81;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.02);
		t91 = RandomFloat(0,0.02);
		tx9 += t9;
		ty9 += t91;
		centru_p9->x += t9;
		centru_p9->y += t91;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
		
			tx9 -= t9;
			ty9 -= t91;
			centru_p9->x -= t9;
			centru_p9->y -= t91;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10 = RandomFloat(0,0.02);
		t101 = RandomFloat(0,0.02);
	    tx10 += t10;
		ty10 += t101;
		centru_p10->x += t10;
		centru_p10->y += t101;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
		
		    tx10-= t10;
			ty10 -= t101;
			centru_p10->x -= t10;
			centru_p10->y -= t101;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			
		}
		t = RandomFloat(0,0.04);

		tx14 += t;
		ty14 += 0;
		centru_p14->x += t;
		centru_p14->y += 0;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx14 -= t;
			ty14 += 0;
			centru_p14->x -= t;
			centru_p14->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx13 += t;
		ty13 += 0;
		centru_p13->x += t;
		centru_p13->y += 0;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx13 -= t;
			ty13 += 0;
			centru_p13->x -= t;
			centru_p13->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty12 += t;
		tx12 += 0;
		centru_p12->x += 0;
		centru_p12->y += t;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			ty12 -= t;
			tx12 += 0;
			centru_p12->x -= 0;
			centru_p12->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx11 += t;
		ty11 += t;
		centru_p11->x += t;
		centru_p11->y += t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx11 -= t;
			ty11 -= t;
			centru_p11->x -= t;
			centru_p11->y -= t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.03);
		tx15 -= t;
		ty15 += 0;
		centru_p15->x -= t;
		centru_p15->y -= 0;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx15 += t;
			ty15 += 0;
			centru_p15->x += t;
			centru_p15->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 += t;
		ty16 -= t;
		centru_p16->x += t;
		centru_p16->y -= t;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx16 -= t;
			ty16 += t;
			centru_p16->x -= t;
			centru_p16->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 += t;
		ty17 -= t;
		centru_p17->x += t;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx17 -= t;
			ty17 += t;
			centru_p17->x -= t;
			centru_p17->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		tx18 += t;
		ty18 += 0;
		centru_p18->x += t;
		centru_p18->y += 0;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx18 -= t;
			ty18 += 0;
			centru_p18->x -= t;
			centru_p18->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty19 -= t;
		tx19 += 0;
		centru_p19->x -= 0;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			ty19 += t;
			tx19 += 0;
			centru_p19->x += 0;
			centru_p19->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

	}
	else if(iter <= r10){
		pierde_viata = 0;
		t1 = RandomFloatInt(0,0.02);
		tx1 -= t1;
		ty1 += 0;
		centru_p1->x -= t1;
		centru_p1->y += 0;
		distanta = sqrt((x_cerc - centru_p1->x)*(x_cerc - centru_p1->x) + (y_cerc - centru_p1->y)*(y_cerc - centru_p1->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			tx1 += t1;
			ty1 += 0;
			centru_p1->x += t1;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
		
		t2 = RandomFloatInt(0,0.02);
		ty2 -= t2;
		tx2 += 0;
		centru_p2->x += 0;
		centru_p2->y -= t2;
		distanta = sqrt((x_cerc - centru_p2->x)*(x_cerc - centru_p2->x) + (y_cerc - centru_p2->y)*(y_cerc - centru_p2->y));
		suma_raze = 0.6 + 0.25;
		if(distanta < suma_raze){
			ty2 += t2;
			tx2 += 0;
			centru_p2->x += 0;
			centru_p2->y += t2;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t3 = RandomFloat(0,0.02);
		t31 = RandomFloat(0,0.02);
		tx3 += t3;
		ty3 += t31;
		centru_p3->x += t3;
		centru_p3->y += t31;
		distanta = sqrt((x_cerc - centru_p3->x)*(x_cerc - centru_p3->x) + (y_cerc - centru_p3->y)*(y_cerc - centru_p3->y));
		suma_raze = 0.6 + 0.45;
		if(distanta < suma_raze){
			tx3 -= t3;
			ty3 -= t31;
			centru_p3->x -= t3;
			centru_p3->y -= t31;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t4 = RandomFloat(0,0.02);
		t41 = RandomFloat(0,0.02);
		tx4 -= t4;
		ty4 -= t41;
		centru_p4->x -= t4;
		centru_p4->y -= t41;
		distanta = sqrt((x_cerc - centru_p4->x)*(x_cerc - centru_p4->x) + (y_cerc - centru_p4->y)*(y_cerc - centru_p4->y));
		suma_raze = 0.6 + 0.5;
		if(distanta < suma_raze){
			tx4 += t4;
			ty4 += t41;
			centru_p4->x += t4;
			centru_p4->y += t41;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t5 = RandomFloat(0,0.02);
		t51 = RandomFloat(0,0.02);
		tx5 -= t5;
		ty5 += t51;
		centru_p5->x -= t5;
		centru_p5->y += t51;
		distanta = sqrt((x_cerc - centru_p5->x)*(x_cerc - centru_p5->x) + (y_cerc - centru_p5->y)*(y_cerc - centru_p5->y));
		suma_raze = 0.6 + 0.375;
		if(distanta < suma_raze){
			tx5 += t5;
			ty5 -= t51;
			centru_p5->x += t5;
			centru_p5->y -= t51;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t6 = RandomFloat(0,0.02);
		t61 = RandomFloat(0,0.02);
		tx6 += t6;
		ty6 -= t61;
		centru_p6->x += t6;
		centru_p6->y -= t61;
		distanta = sqrt((x_cerc - centru_p6->x)*(x_cerc - centru_p6->x) + (y_cerc - centru_p6->y)*(y_cerc - centru_p6->y));
		suma_raze = 0.6 + 0.4;
		if(distanta < suma_raze){
			tx6 -= t6;
			ty6 += t61;
			centru_p6->x -= t6;
			centru_p6->y += t61;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t7 = RandomFloat(0,0.02);
		t71 = RandomFloat(0,0.02);
		tx7 -= t7;
		ty7 -= t71;
		centru_p7->x -= t7;
		centru_p7->y -= t71;
		distanta = sqrt((x_cerc - centru_p7->x)*(x_cerc - centru_p7->x) + (y_cerc - centru_p7->y)*(y_cerc - centru_p7->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			tx7 += t7;
			ty7 += t71;
			centru_p7->x += t7;
			centru_p7->y += t71;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t8 = RandomFloat(0,0.02);
		t81 = RandomFloat(0,0.02);
		tx8 -= t8;
		ty8 -= t81;
		centru_p8->x -= t8;
		centru_p8->y -= t81;
		distanta = sqrt((x_cerc - centru_p8->x)*(x_cerc - centru_p8->x) + (y_cerc - centru_p8->y)*(y_cerc - centru_p8->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			tx8 += t8;
			ty8 += t81;
			centru_p8->x += t8;
			centru_p8->y += t81;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t9 = RandomFloat(0,0.02);
		t91 = RandomFloat(0,0.02);
		tx9 -= t9;
		ty9 -= t91;
		centru_p9->x -= t9;
		centru_p9->y -= t91;
		distanta = sqrt((x_cerc - centru_p9->x)*(x_cerc - centru_p9->x) + (y_cerc - centru_p9->y)*(y_cerc - centru_p9->y));
		suma_raze = 0.6 + 0.2;
		if(distanta < suma_raze){
			tx9 += t9;
			ty9 += t91;
			centru_p9->x += t9;
			centru_p9->y += t91;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t10 = RandomFloat(0,0.02);
		t101 = RandomFloat(0,0.02);
		tx10 -= t10;
		ty10 -= t101;
		
		centru_p10->x -= t10;
		centru_p10->y -= t101;
		distanta = sqrt((x_cerc - centru_p10->x)*(x_cerc - centru_p10->x) + (y_cerc - centru_p10->y)*(y_cerc - centru_p10->y));
		suma_raze = 0.6 + 0.3;
		if(distanta < suma_raze){
			tx10 += t10;
			ty10 += t101;
			centru_p10->x += t10;
			centru_p10->y += t101;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
			
		}
		t = RandomFloat(0,0.04);


		tx14 -= t;
		ty14 += 0;
		centru_p14->x -= t;
		centru_p14->y += 0;
		distanta = sqrt((x_cerc - centru_p14->x)*(x_cerc - centru_p14->x) + (y_cerc - centru_p14->y)*(y_cerc - centru_p14->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx14 += t;
			ty14 += 0;
			centru_p14->x += t;
			centru_p14->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx13 -= t;
		ty13 += 0;
		centru_p13->x -= t;
		centru_p13->y += 0;
		distanta = sqrt((x_cerc - centru_p13->x)*(x_cerc - centru_p13->x) + (y_cerc - centru_p13->y)*(y_cerc - centru_p13->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx13 += t;
			ty13 += 0;
			centru_p13->x += t;
			centru_p13->y += 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty12 -= t;
		tx12 += 0;
		centru_p12->x += 0;
		centru_p12->y -= t;
		distanta = sqrt((x_cerc - centru_p12->x)*(x_cerc - centru_p12->x) + (y_cerc - centru_p12->y)*(y_cerc - centru_p12->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			ty12 += t;
			tx12 += 0;
			centru_p12->x += 0;
			centru_p12->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx11 -= t;
		ty11 -= t;
		centru_p11->x -= t;
		centru_p11->y -= t;
		distanta = sqrt((x_cerc - centru_p11->x)*(x_cerc - centru_p11->x) + (y_cerc - centru_p11->y)*(y_cerc - centru_p11->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx11 += t;
			ty11 += t;
			centru_p11->x += t;
			centru_p11->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		t = RandomFloat(0,0.02);
		tx15 += t;
		ty15 += 0;
		centru_p15->x += t;
		centru_p15->y -= 0;
		distanta = sqrt((x_cerc - centru_p15->x)*(x_cerc - centru_p15->x) + (y_cerc - centru_p15->y)*(y_cerc - centru_p15->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx15 -= t;
			ty15 += 0;
			centru_p15->x -= t;
			centru_p15->y -= 0;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx16 -= t;
		ty16 -= t;
		centru_p16->x -= t;
		centru_p16->y -= t;
		distanta = sqrt((x_cerc - centru_p16->x)*(x_cerc - centru_p16->x) + (y_cerc - centru_p16->y)*(y_cerc - centru_p16->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx16 += t;
			ty16 += t;
			centru_p16->x += t;
			centru_p16->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		tx17 -= t;
		ty17 -= t;
		centru_p17->x -= t;
		centru_p17->y -= t;
		distanta = sqrt((x_cerc - centru_p17->x)*(x_cerc - centru_p17->x) + (y_cerc - centru_p17->y)*(y_cerc - centru_p17->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx17 += t;
			ty17 += t;
			centru_p17->x += t;
			centru_p17->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
	
		tx18 -= t;
		ty18 += 0;
		centru_p18->x -= t;
		centru_p18->y += 0;
		distanta = sqrt((x_cerc - centru_p18->x)*(x_cerc - centru_p18->x) + (y_cerc - centru_p18->y)*(y_cerc - centru_p18->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			tx18 += t;
			ty18 += 0;	
			centru_p18->x += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}

		ty19 -= t;
		tx19 = 0;
		centru_p19->x -= 0;
		centru_p19->y -= t;
		distanta = sqrt((x_cerc - centru_p19->x)*(x_cerc - centru_p19->x) + (y_cerc - centru_p19->y)*(y_cerc - centru_p19->y));
		suma_raze = 0.6 + 0.125;
		if(distanta < suma_raze){
			ty19 += t;
			tx19 += 0;
			centru_p19->x -= 0;
			centru_p19->y += t;
			nr_vieti_naveta--;
			string v_naveta = int_to_string(nr_vieti_naveta);
			removeText_from_Visual2D(vieti_nava1, v2d1);
			vieti_nava1 = new Text(v_naveta, Point2D(4.5, -0.1), Color(1,0,1),BITMAP_TIMES_ROMAN_24);
			addText_to_Visual2D(vieti_nava1, v2d1);
		}
	}
	
	else
		iter = 0;
		
	if(ok == true){
	
		if((x_cerc_arma <= 6 && x_cerc_arma >= -6 && y_cerc_arma <= 6 && y_cerc_arma >= -6)){
			xxxx += 0.1*panta;
			yyyy += 0.1;
			x_cerc_arma += 0.1*panta;
			y_cerc_arma += 0.1;
			/*Transform2D::loadIdentityMatrix();
			Transform2D::translateMatrix(tx1,ty1);
			Transform2D::applyTransform(impuscatura);*/
		}
		else{
			removeObject2D_from_Visual2D(impuscatura, v2d2);
			impuscatura = new Circle2D(Point2D(arma->transf_points[2]->x, arma->transf_points[2]->y), 0.1, Color(1,0,0), true);
			addObject2D_to_Visual2D(impuscatura, v2d2);
			ok = false;
		
		}
	}
	//verific daca s-a terminat jocul(daca nava nu mai are nici o  viata)
	if(nr_vieti_naveta < 0){
		removeObject2D_from_Visual2D(poligon_1, v2d2);
		removeObject2D_from_Visual2D(poligon_2, v2d2);
		removeObject2D_from_Visual2D(poligon_2_copy, v2d2);
		removeObject2D_from_Visual2D(poligon_3, v2d2);
		removeObject2D_from_Visual2D(poligon_4, v2d2);
		removeObject2D_from_Visual2D(poligon_5, v2d2);
		removeObject2D_from_Visual2D(poligon_6, v2d2);
		removeObject2D_from_Visual2D(poligon_7, v2d2);
		removeObject2D_from_Visual2D(poligon_8, v2d2);
		removeObject2D_from_Visual2D(poligon_9, v2d2);
		removeObject2D_from_Visual2D(poligon_10, v2d2);
		removeObject2D_from_Visual2D(poligon_11, v2d2);
		removeObject2D_from_Visual2D(poligon_12, v2d2);
		removeObject2D_from_Visual2D(poligon_13, v2d2);
		removeObject2D_from_Visual2D(poligon_14, v2d2);
		removeObject2D_from_Visual2D(poligon_15, v2d2);
		removeObject2D_from_Visual2D(poligon_16, v2d2);
		removeObject2D_from_Visual2D(poligon_17, v2d2);
		removeObject2D_from_Visual2D(poligon_18, v2d2);
		removeObject2D_from_Visual2D(poligon_19, v2d2);
		removeObject2D_from_Visual2D(arma, v2d2);
		removeObject2D_from_Visual2D(cerc_nava, v2d2);
		removeObject2D_from_Visual2D(poligon_nava, v2d2);
		game_over = new Text("GAME OVER", Point2D(-1,0), Color(0,1,0), BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(game_over, v2d2);
	}

	//detectarea coliziunilor intre inamici si proiectil si initializarea scorului
	if(sqrt(pow((centru_p1->x - impuscatura->transf_points[0]->x),2) + pow((centru_p1->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.4){
		removeObject2D_from_Visual2D(poligon_1, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p2->x - impuscatura->transf_points[0]->x),2) + pow((centru_p2->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.25){
		removeObject2D_from_Visual2D(poligon_2, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p3->x - impuscatura->transf_points[0]->x),2) + pow((centru_p3->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.45){
		removeObject2D_from_Visual2D(poligon_3, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p4->x - impuscatura->transf_points[0]->x),2) + pow((centru_p4->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.5){
		removeObject2D_from_Visual2D(poligon_4, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p5->x - impuscatura->transf_points[0]->x),2) + pow((centru_p5->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.375){
		removeObject2D_from_Visual2D(poligon_5, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p6->x - impuscatura->transf_points[0]->x),2) + pow((centru_p6->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.4){
		removeObject2D_from_Visual2D(poligon_6, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p7->x - impuscatura->transf_points[0]->x),2) + pow((centru_p7->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.3){
		removeObject2D_from_Visual2D(poligon_7, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p8->x - impuscatura->transf_points[0]->x),2) + pow((centru_p8->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.3){
		removeObject2D_from_Visual2D(poligon_8, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p9->x - impuscatura->transf_points[0]->x),2) + pow((centru_p9->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.2){
		removeObject2D_from_Visual2D(poligon_9, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p10->x - impuscatura->transf_points[0]->x),2) + pow((centru_p10->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.3){
		removeObject2D_from_Visual2D(poligon_10, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p11->x - impuscatura->transf_points[0]->x),2) + pow((centru_p11->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_11, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p12->x - impuscatura->transf_points[0]->x),2) + pow((centru_p12->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_12, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p13->x - impuscatura->transf_points[0]->x),2) + pow((centru_p13->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_13, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p14->x - impuscatura->transf_points[0]->x),2) + pow((centru_p14->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_14, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p15->x - impuscatura->transf_points[0]->x),2) + pow((centru_p15->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.3){
		removeObject2D_from_Visual2D(poligon_15, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p16->x - impuscatura->transf_points[0]->x),2) + pow((centru_p16->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_16, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p17->x - impuscatura->transf_points[0]->x),2) + pow((centru_p17->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_17, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p18->x - impuscatura->transf_points[0]->x),2) + pow((centru_p18->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_18, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	if(sqrt(pow((centru_p19->x - impuscatura->transf_points[0]->x),2) + pow((centru_p19->y - impuscatura->transf_points[0]->y),2)) < 0.1 + 0.125){
		removeObject2D_from_Visual2D(poligon_19, v2d2);
		scor_naveta += 10;
		string s = int_to_string(scor_naveta);
		removeText_from_Visual2D(scor1, v2d1);
		removeObject2D_from_Visual2D(impuscatura, v2d2);
		scor1 = new Text(s,Point2D(-0.5,-0.5),Color(0,1,0),BITMAP_TIMES_ROMAN_24);
		addText_to_Visual2D(scor1, v2d1);
	}
	
	//aplicare transformari pentru fiecare inamic
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(0.1*panta--,l++);
	Transform2D::applyTransform(impuscatura);

	//2 patrate albastre
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx1,ty1);
	Transform2D::applyTransform(poligon_1);
	

	//patrat cu romb
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx2,ty2);
	Transform2D::applyTransform(poligon_2);

	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx2,ty2);
	Transform2D::applyTransform(poligon_2_copy);
	
	//avion albastru
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx3,ty3);
	Transform2D::applyTransform(poligon_3);
	
	//romb cu patrat
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx4,ty4);
	Transform2D::applyTransform(poligon_4);

	//multe patrate verzi
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx5,ty5);
	Transform2D::applyTransform(poligon_5);

	//avion verde spre nava
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx6,ty6);
	Transform2D::applyTransform(poligon_6);

	//seluta verde
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx7,ty7);
	Transform2D::rotateMatrix(tx7);
	Transform2D::applyTransform(poligon_7);

	//steluta mova
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx8,ty8);
	Transform2D::applyTransform(poligon_8);

	//2 cuburi blue
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx9,ty9);
	Transform2D::applyTransform(poligon_9);

	//trifoi
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx10,ty10);
	Transform2D::applyTransform(poligon_10);
	

	//triunghi 1
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx11,ty11);
	Transform2D::applyTransform(poligon_11);

	//triunghi 2
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx12,ty12);
	Transform2D::applyTransform(poligon_12);

	//triunghi 3
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx13,ty13);
	Transform2D::applyTransform(poligon_13);

	//trunghi 4
	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx14,ty14);
	Transform2D::applyTransform(poligon_14);
	

	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx15,ty15);
	Transform2D::applyTransform(poligon_15);

	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx16,ty16);
	Transform2D::applyTransform(poligon_16);

	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx17,ty17);
	Transform2D::applyTransform(poligon_17);

	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx18,ty18);
	Transform2D::applyTransform(poligon_18);

	Transform2D::loadIdentityMatrix();
	Transform2D::translateMatrix(tx19,ty19);
	Transform2D::applyTransform(poligon_19);

	
	}

	//functia care defineste ce se intampla cand se apasa pe tastatura
void DrawingWindow::onKey(unsigned char key)
{
	
	float ac = 0, co = 0;
	Transform2D::loadIdentityMatrix();

	if(key == KEY_DOWN){
		x_cerc += 0.1;
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(0.1,0);
		Transform2D::applyTransform_o(cerc_nava);
		Transform2D::applyTransform_o(poligon_nava);
		Transform2D::applyTransform_o(arma);
	}
	if(key == KEY_UP){
		x_cerc -= 0.1;
		Transform2D::loadIdentityMatrix();
		Transform2D::translateMatrix(-0.1,0);
		Transform2D::applyTransform_o(cerc_nava);
		Transform2D::applyTransform_o(poligon_nava);
		Transform2D::applyTransform_o(arma);
	}
	if(key == KEY_LEFT){
		rotire_nava += 0.1;
		rotire_left += 0.1;
		rotire_right = rotire_left - 0.1;
		if(x_cerc >= 0){
		Transform2D::translateMatrix(-x_cerc,3);
		Transform2D::rotateMatrix(0.1);
		Transform2D::translateMatrix(x_cerc, -3);
		Transform2D::applyTransform_o(cerc_nava);
		Transform2D::applyTransform_o(poligon_nava);
		Transform2D::applyTransform_o(arma);
		}
	    if(x_cerc < 0){
		Transform2D::translateMatrix(x_cerc,3);
		Transform2D::rotateMatrix(0.1);
		Transform2D::translateMatrix(-x_cerc, -3);
		Transform2D::applyTransform_o(cerc_nava);
		Transform2D::applyTransform_o(poligon_nava);
		Transform2D::applyTransform_o(arma);
		}

	}
	if(key == KEY_RIGHT){
		rotire_nava -= 0.1;
		rotire_right -= 0.1;
		rotire_left = rotire_right + 0.1;
		if(x_cerc >= 0){
		Transform2D::translateMatrix(-x_cerc,3);
		Transform2D::rotateMatrix(-0.1);
		Transform2D::translateMatrix(x_cerc, -3);
		Transform2D::applyTransform_o(cerc_nava);
		Transform2D::applyTransform_o(poligon_nava);
		Transform2D::applyTransform_o(arma);
		
		}
	    if(x_cerc < 0){
		
		Transform2D::translateMatrix(x_cerc,3);
		Transform2D::rotateMatrix(-0.1);
		Transform2D::translateMatrix(-x_cerc, -3);
		Transform2D::applyTransform_o(cerc_nava);
		Transform2D::applyTransform_o(poligon_nava);
		Transform2D::applyTransform_o(arma);
		
		}
		
	}
	
	if(key == 'z'){
		arma->color.r = 1;
		arma->color.b = 0;
		arma->color.g = 0;
	}

	if(key == 'x'){
		arma->color.r = 0;
		arma->color.b = 0;
		arma->color.g = 0;
	}
	if((key == KEY_SPACE) && (arma->color.r == 1) && (arma->color.b == 0) && (arma->color.g == 0)){
		ok = true;
		if(y_cerc == arma->transf_points[2]->y)
			panta = 0;
		else
			panta = abs((x_cerc - arma->transf_points[2]->x) / (y_cerc - arma->transf_points[2]->y));
	   
	}
	
}

//functia care se apeleaza la redimensionarea ferestrei
void DrawingWindow::onReshape(int width,int height)
{

	v2d1->poarta(0,0,width,height/8); 
	v2d2->poarta(0,height/8,width,height);

}


//functia care defineste ce se intampla cand se da click pe mouse
void DrawingWindow::onMouse(int button,int state,int x, int y)
{
	
}


int main(int argc, char** argv)
{
	//creare fereastra
	DrawingWindow dw(argc, argv, 1000, 600, 200, 50, "Laborator EGC");
	
	//se apeleaza functia init() - in care s-au adaugat obiecte
	dw.init();
	
	//se intra in bucla principala de desenare - care face posibila desenarea, animatia si procesarea evenimentelor
	dw.run();
	return 0;

}