
    Elemente de grafica pe calculator - Tema 1
        Geometry Wars
        Sirbu Maria-Dorinela 332CB


1. Cerinta
	Implementarea unui joc, Geometry Wars. Jocul este compus dintr-o naveta si multi inamici care se misca aleator pe tabla de joc. Atunci cand un inamic loveste nava aceasta pierde
	o viata, cand nava impusca inamicul acesta dispare iar scorul navei creste. Nava este condusa de jucator prin intermediul unor taste. Jocul se termina cand nava nu mai are nici
	o viata sau cand nava a impuscat toti inamicii.
2. Utilizare
	Programul nu are parametri de intrare.
     
Taste : 
		[UP]
			deplasarea navei inainte
		[DOWN]
			deplasarea navei inapoi
		[RIGHT]
			rotirea navei la dreapta
		[LEFT]
			rotirea navei la stanga
		[z]
			activarea armei
		[x]
			dezactivarea armei
		[BACKSPACE]
			lansare proiectil


         In partea de sus a ferestrei, in mijloc, se gaseste scorul navetei, iar in partea dreapta sus vietiile acesteia.
		 In momentul in care jocul se termina in mijlocul ferestrei apara textul "GAME OVER".
3. Implementare

	Tema a fost facuta in Visual Studio 2012 C++, Windows 8.
    Pentru implementare am folosit scheletul de cod din cadrul laboratorului 2.

4. Testare
	Tema a fost testata pe Visual Studio 2012, Windows 8. Pentru testarea temei am verificat colizunile dintre nava si inamici, deplasarea corecta a navei, functionalitatea corecta a armei.

5. Probleme aparute

Explicati :
    Am o problema la stergerea inamicilor atunci cand sunt impuscati de nava. Inamicul dispare doar vizual, deoarece scorul navei creste si daca mai trage odata in locul unde a fost
	un inamic deja sters.
    

6. Continutul Arhivei

    main.cpp
        Sursa principala a aplicatiei. Aici construiesc inamicii, naveta, tratez coliziunile, retin scorul si vietile navetei.
    Programul contine toate antetele date in cadrul laboratorului 2, de asemenea si clasele DrawingWindow.cpp, Transform2D.cpp si Visual2D.cpp.
    README
        acest fisier

7. Functionalitati

    Functionalitati Standard (ca in enunt)
        Miscare naveta
        Afisare scor si vietile navetei
        Plasare inamici
        Coliziuni intre nava si inamici
	   Coliziuni intre inamici si proiectil
    Functionalitati Bonus
        Lansare proiectil
	   Inamici cu structuri mai complexe
 